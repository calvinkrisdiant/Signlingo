package com.capstone.signlingo

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.capstone.signlingo.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.loginButton.setOnClickListener {
            // Handle login button click
            startActivity(Intent(this@LoginActivity, HomeActivity::class.java))
        }

//        binding.signupButton.setOnClickListener {
//            // Handle sign up button click
//        }
//
//        binding.googleSigninButton.setOnClickListener {
//            // Handle Google Sign-In button click
//        }
    }
}
