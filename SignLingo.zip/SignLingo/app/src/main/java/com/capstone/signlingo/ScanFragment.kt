package com.capstone.signlingo

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import androidx.fragment.app.Fragment

class ScanFragment : Fragment() {
    private lateinit var imagePreview: ImageView
    private lateinit var galleryButton: Button
    private lateinit var cameraButton: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView = inflater.inflate(R.layout.fragment_scan, container, false)

        // Inisialisasi komponen
        imagePreview = rootView.findViewById(R.id.imagePreview)
        galleryButton = rootView.findViewById(R.id.galleryButton)
        cameraButton = rootView.findViewById(R.id.cameraButton)

        // Tambahkan listener untuk tombol galeri
        galleryButton.setOnClickListener {
            openGallery()
        }

        // Tambahkan listener untuk tombol kamera
        cameraButton.setOnClickListener {
            openCamera()
        }

        return rootView
    }

    private fun openGallery() {
        // Buat Intent untuk membuka galeri
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, GALLERY_REQUEST_CODE)
    }

    private fun openCamera() {
        // Buat Intent untuk membuka kamera
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, CAMERA_REQUEST_CODE)
    }

    // Override metode onActivityResult untuk menangani hasil pemilihan gambar dari galeri atau pengambilan gambar dari kamera
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                GALLERY_REQUEST_CODE -> {
                    // Dapatkan URI gambar yang dipilih dari galeri
                    val selectedImageUri = data?.data
                    if (selectedImageUri != null) {
                        // Tampilkan gambar di ImageView
                        imagePreview.setImageURI(selectedImageUri)
                    }
                }
                CAMERA_REQUEST_CODE -> {
                    // Dapatkan gambar yang diambil dari kamera
                    val capturedImage = data?.extras?.get("data") as? Bitmap
                    if (capturedImage != null) {
                        // Tampilkan gambar di ImageView
                        imagePreview.setImageBitmap(capturedImage)
                    }
                }
            }
        }
    }

    companion object {
        private const val GALLERY_REQUEST_CODE = 123
        private const val CAMERA_REQUEST_CODE = 456
    }
}
