package com.capstone.signlingo


import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import com.capstone.signlingo.databinding.ActivitySignupBinding

class SignupActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Add text change listeners to enable signup button when fields are not empty
        binding.username.addTextChangedListener(signupTextWatcher)
        binding.email.addTextChangedListener(signupTextWatcher)
        binding.password.addTextChangedListener(signupTextWatcher)

        // Show password functionality
        binding.showPassword.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                binding.password.inputType = android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            } else {
                binding.password.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            binding.password.setSelection(binding.password.text.length) // Move cursor to the end
        }

        // Handle signup button click
        binding.signupButton.setOnClickListener {
            // Add your signup logic here
        }
    }

    private val signupTextWatcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            val usernameInput = binding.username.text.toString().trim()
            val emailInput = binding.email.text.toString().trim()
            val passwordInput = binding.password.text.toString().trim()
            binding.signupButton.isEnabled = usernameInput.isNotEmpty() && emailInput.isNotEmpty() && passwordInput.isNotEmpty()
            binding.signupButton.setBackgroundResource(
                if (usernameInput.isNotEmpty() && emailInput.isNotEmpty() && passwordInput.isNotEmpty())
                    R.drawable.button_background_enabled
                else
                    R.drawable.button_background_disabled
            )
        }

        override fun afterTextChanged(s: Editable?) {}
    }
}
